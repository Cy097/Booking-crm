import { NextResponse } from 'next/server';
import { findUserByEmail } from '@/lib/db';
import { comparePassword, signToken } from '@/lib/auth';

export async function POST(request) {
  try {
    const { email, password } = await request.json();

    if (!email || !password) {
      return NextResponse.json({ error: 'Email and password are required' }, { status: 400 });
    }

    const user = await findUserByEmail(email);
    if (!user) {
      return NextResponse.json({ error: 'Invalid email or password' }, { status: 401 });
    }

    const isValid = await comparePassword(password, user.passwordHash);
    if (!isValid) {
      return NextResponse.json({ error: 'Invalid email or password' }, { status: 401 });
    }

    const token = await signToken({ userId: user.id, email: user.email, name: user.name, role: user.role || 'user' });

    const response = NextResponse.json({
      success: true,
      user: { id: user.id, email: user.email, name: user.name, role: user.role || 'user' }
    });

    const TEN_YEARS_IN_SECONDS = 10 * 365 * 24 * 60 * 60;
    response.cookies.set('auth_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: TEN_YEARS_IN_SECONDS,
      expires: new Date(Date.now() + TEN_YEARS_IN_SECONDS * 1000)
    });

    return response;
  } catch (err) {
    console.error('[v0] Login database error:', err);
    return NextResponse.json(
      { error: 'Login is temporarily unavailable. Check the MongoDB Atlas connection and try again.' },
      { status: 503 }
    );
  }
}
